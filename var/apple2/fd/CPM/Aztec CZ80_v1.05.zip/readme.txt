ReadMe for a280105

This directory contains Aztec CZ80 version 1.05 which amazingly fits on 
2 single sided Apple II CP/M 80 disks.

The down-side is that the C link library is pretty tiny:

**DIR**     supp8080    fprintf     fscanf      scan        fltlib      
fopen       fread       **DIR**     fseek       fgets       fputs       
getc        putc        ungetc      getbuff     setbuf      alloc       
format      callcpm     croot       open        read        write       
lseek       posit       **DIR**     blkio       rename      unlink      
atof        atol        atoi        block       atol        atoi        
block       string      toupper     closall     lsubs       fstub       

Two disk images are provided:

a280105.dsk - the work disk - place into drive A:
b280105.dsk - the compiler disk - place into drive B:

To compile anything like the exmpl.c program that is on the work disk
type "SUBMIT CC EXMPL" and press [Return]. 

Have Fun!

Bill Buckels February 2009


