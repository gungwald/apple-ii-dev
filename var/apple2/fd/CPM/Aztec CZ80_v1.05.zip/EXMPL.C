#include "stdio.h"

main()
{
	char buf[80];

	printf("please enter your name: ");
	gets(buf);
	printf("hello, %s, welcome to the growing community of Aztec C users.\n", buf);
	getchar();
}

